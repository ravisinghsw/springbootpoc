package com.example.demo.pojo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Author {

	@Id
	private int author_id;
	private String author_name;
	private String author_contact;
	private int ISBN;
	
	public Author() {
		// TODO Auto-generated constructor stub
	}
	

	public Author(int author_id, String author_name, String author_contact, int iSBN) {
		super();
		this.author_id = author_id;
		this.author_name = author_name;
		this.author_contact = author_contact;
		ISBN = iSBN;
	}


	public int getAuthor_id() {
		return author_id;
	}

	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}

	public String getAuthor_name() {
		return author_name;
	}

	public void setAuthor_name(String author_name) {
		this.author_name = author_name;
	}

	public String getAuthor_contact() {
		return author_contact;
	}

	public void setAuthor_contact(String author_contact) {
		this.author_contact = author_contact;
	}


	public int getISBN() {
		return ISBN;
	}


	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	
	
}
