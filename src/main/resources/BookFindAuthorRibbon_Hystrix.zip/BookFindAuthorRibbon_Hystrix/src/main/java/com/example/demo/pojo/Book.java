package com.example.demo.pojo;

import java.util.List;

public class Book {
	private int ISBN;
	private String book_name;
	private String publisher;
	private List<Author> authors;
	
	
	public Book() {
		// TODO Auto-generated constructor stub
	}


	public Book(int iSBN, String book_name, String publisher, List<Author> authors) {
		super();
		ISBN = iSBN;
		this.book_name = book_name;
		this.publisher = publisher;
		this.authors = authors;
	}


	public Book(int iSBN, String book_name, String publisher) {
		super();
		ISBN = iSBN;
		this.book_name = book_name;
		this.publisher = publisher;
	}


	public int getISBN() {
		return ISBN;
	}


	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}


	public String getBook_name() {
		return book_name;
	}


	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}


	public String getPublisher() {
		return publisher;
	}


	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}


	public List<Author> getAuthors() {
		return authors;
	}


	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}
	
	

}
